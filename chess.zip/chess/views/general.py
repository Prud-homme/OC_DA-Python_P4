def entry_request(message: str) -> str:
    """Display a message related to the requested entry"""
    return input(message)


def display_message(message: str) -> None:
    """Display a message related to the requested entry"""
    return print(message)
